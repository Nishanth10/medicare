﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.dmcm.dao
{
    public class QueriesImpl
    {
        public static string _addMedicareService = "insert into [medicare_services] values(@service,@description,@amount)";
        public static string _getAllMedicareServices = "select * from [medicare_services](nolock)";
        public static string _updateMedicareServices = "update [medicare_services] set ms_service=@service,ms_description=@description,ms_amount=@amount where ms_id=@id";
    }
}
