﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.dmcm.dao
{
    public class ConstantsImpl
    {
        public static string _id = "@id";
        public static string _service = "@service";
        public static string _description = "@description";
        public static string _amount = "@amount";

        public static string _medicareServiceTableId = "ms_id";
        public static string _medicareServiceTableService = "ms_service";
        public static string _medicareServiceTableDescription = "ms_description";
        public static string _medicareServiceTableAmount = "ms_amount";
    }
}
