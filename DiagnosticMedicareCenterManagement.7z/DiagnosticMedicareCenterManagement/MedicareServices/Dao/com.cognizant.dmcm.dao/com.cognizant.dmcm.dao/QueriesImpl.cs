﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.dmcm.dao
{
    public class QueriesImpl
    {
        public static string _addMedicareService = "insert into [medicare_services] values(@service,@description,@amount)";
        public static string _getAllMedicareServices = "select * from [medicare_services](nolock)";
        public static string _updateMedicareServices = "update [medicare_services] set ms_service=@service,ms_description=@description,ms_amount=@amount where ms_id=@id";
        public static string _getSpecificMedicareServicesById = "select * from [medicare_services](nolock) where ms_id=@id";

        public static string _registerDoctor = "insert into [doctor] values(@firstName,@lastName,@age,@gender,@dob,@phone,@altphone,@email,@password,@address_line1,@address_line2,@city,@state,@zipcode,@degree,@speciality,@work_hours,@clinic_name,@medicareServiceId)";
        public static string _loginDoctor = "select * from [doctor] (nolock)";
        public static string _addHistory = "insert into [medical_test_history] values(@patientId,@doctorId,@medicareServiceId,@serviceDate,@testResultDate,@diag1ActualValue,@diag1NormalRange,@diag2ActualValue,@diag2NormalRange,@diag3ActualValue,@diag3NormalRange,@diag4ActualValue,@diag4NormalRange,@diag5ActualValue,@diag5NormalRange,@diag6ActualValue,@diag6NormalRange,@doctorComments,@otherInfo)";
        public static string _viewMedicalHistory = "select * from [medical_test_history] (nolock)";
        public static string _displayFilteredMedicalHistoryById = "select * from [medical_test_history] where mth_pt_id =@patientId;";
        public static string _updateMedicalHistory = "update [medical_test_history] set mth_test_result_date=@testResultDate,mth_diag1_actual_value=@diag1ActualValue,mth_diag1_normal_range=@diag1NormalRange,	mth_diag2_actual_value=@diag2ActualValue,mth_diag2_normal_range=@diag2NormalRange,mth_diag3_actual_value=@diag3ActualValue,mth_diag3_normal_range=@diag3NormalRange,mth_diag4_actual_value=@diag4ActualValue,mth_diag4_normal_range=@diag4NormalRange,mth_diag5_actual_value=@diag5ActualValue,mth_diag5_normal_range=@diag5NormalRange,mth_diag6_actual_value=@diag6ActualValue,mth_diag6_normal_range=@diag6NormalRange,mth_doctors_comments=@doctorComments,mth_other_info=@otherInfo";

    }
}
