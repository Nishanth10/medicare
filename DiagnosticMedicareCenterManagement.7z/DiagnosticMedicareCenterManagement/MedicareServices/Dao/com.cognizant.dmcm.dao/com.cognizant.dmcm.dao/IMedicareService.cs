﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using namespace
using com.cognizant.dmcm.model;

namespace com.cognizant.dmcm.dao
{
    interface IMedicareService
    {
        int AddMedicareService(MedicareServices medicareServices);
        List<MedicareServices> GetAllMedicareServices();
        int ModifyMedicareService(MedicareServices medicareService);
    }
}
