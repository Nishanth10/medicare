﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string patientId = "PAT002";
        txtPatientId.Text = patientId.ToString();

        string doctorId = "DOC001";
        txtDoctorId.Text = doctorId.ToString();

        long medicareId = 1;
        txtMedicareId.Text = medicareId.ToString();
    }

    protected void BtnReportSave_Click(object sender, EventArgs e)
    {
        MedicalHistoryDaoSqlImpl medicalTestHistoryDao = new MedicalHistoryDaoSqlImpl();
        MedicalTestHistory medicalTestHistory = new MedicalTestHistory();
        medicalTestHistory.PatientId = txtPatientId.Text;
        medicalTestHistory.DoctorId = txtDoctorId.Text;
        medicalTestHistory.MedicareServiceId = long.Parse(txtMedicareId.Text);
        medicalTestHistory.ServiceDate = txtServiceDate.Text;
        medicalTestHistory.TestResultDate = txtTestResultDate.Text;
        medicalTestHistory.Diag1ActualValue = long.Parse(txtDiag1Actual.Text);
        medicalTestHistory.Diag1NormalRange = long.Parse(TxtDiag1Normal.Text);
        if (txtDiag2Actual.Text == "")
        {
            medicalTestHistory.Diag2ActualValue = 0;
        }
        else
        {
            medicalTestHistory.Diag2ActualValue = long.Parse(txtDiag2Actual.Text);
        }
        if (txtDiag2Normal.Text == "")
        {
            medicalTestHistory.Diag2NormalRange = 0;
        }
        else
        {
            medicalTestHistory.Diag2NormalRange = long.Parse(txtDiag2Normal.Text);
        }


        if (txtDiag3Actual.Text == "")
        {
            medicalTestHistory.Diag3ActualValue = 0;
        }
        else
        {
            medicalTestHistory.Diag3ActualValue = long.Parse(txtDiag3Actual.Text);
        }
        if (txtDiag3Normal.Text == "")
        {
            medicalTestHistory.Diag3NormalRange = 0;
        }
        else
        {
            medicalTestHistory.Diag3NormalRange = long.Parse(txtDiag3Normal.Text);
        }


        if (txtDiag4Actual.Text == "")
        {
            medicalTestHistory.Diag4ActualValue = 0;
        }
        else
        {
            medicalTestHistory.Diag4ActualValue = long.Parse(txtDiag4Actual.Text);
        }
        if (txtDiag4Normal.Text == "")
        {
            medicalTestHistory.Diag4NormalRange = 0;
        }
        else
        {
            medicalTestHistory.Diag4NormalRange = long.Parse(txtDiag4Normal.Text);
        }


        if (txtDiag5Actual.Text == "")
        {
            medicalTestHistory.Diag5ActualValue = 0;
        }
        else
        {
            medicalTestHistory.Diag5ActualValue = long.Parse(txtDiag5Actual.Text);
        }
        if (txtDiag5Normal.Text == "")
        {
            medicalTestHistory.Diag5NormalRange = 0;
        }
        else
        {
            medicalTestHistory.Diag5NormalRange = long.Parse(txtDiag5Normal.Text);
        }


        if (txtDiag6Actual.Text == "")
        {
            medicalTestHistory.Diag6ActualValue = 0;
        }
        else
        {
            medicalTestHistory.Diag6ActualValue = long.Parse(txtDiag6Actual.Text);
        }
        if (txtDiag6Normal.Text == "")
        {
            medicalTestHistory.Diag6NormalRange = 0;
        }
        else
        {
            medicalTestHistory.Diag6NormalRange = long.Parse(txtDiag6Normal.Text);
        }
        
        medicalTestHistory.DoctorComments = txtDocComments.Text;
        medicalTestHistory.OtherInfo = txtOtherInfo.Text;

        if (medicalTestHistoryDao.AddMedicalHistory(medicalTestHistory)== 1)
        {
            Response.Write("<script>alert('Saved Succesfully');window.location.href='DoctorPage.aspx'</script>");
        }
    }
}