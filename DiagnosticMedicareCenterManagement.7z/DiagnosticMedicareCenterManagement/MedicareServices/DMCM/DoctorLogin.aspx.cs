﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            lblMessage.Visible = false;
        }
    }
    protected void btnDoctorLogin_Click(object sender, EventArgs e)
    {

        DoctorDaoSqlImpl doctorDao = new DoctorDaoSqlImpl();
        int result = doctorDao.DoctorLogin(txtDoctorId.Text, txtDoctorPassword.Text);
        if (result ==1 ) // ie DoctorId and Password matches
        {
            lblMessage.Visible = false;
            lblMessage.Text = "";
            Session["doctorId"] = txtDoctorId.Text;
            Response.Write("<script>alert('Welcome Doctor');window.location.href='DoctorPage.aspx'</script>");
        }
        else //ie userId and Password is not found
        {
            lblMessage.Visible = true;
            lblMessage.Text = "Invalid Credentials...Try Again";
            //clearing old contents from text boxes to write credentials again
            txtDoctorId.Text = "";
            txtDoctorPassword.Text = "";
            //Position write cursor automatically on adminId text box
            txtDoctorId.Focus();
        }
    }
}