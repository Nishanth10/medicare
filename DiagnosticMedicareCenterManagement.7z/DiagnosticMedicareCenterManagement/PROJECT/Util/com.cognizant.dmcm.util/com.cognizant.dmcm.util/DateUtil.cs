﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.dmcm.util
{
    public class DateUtil
    {
        public static DateTime convertToDate(string date)
        {

            DateTime dt = DateTime.ParseExact(date, "dd/MM/yyyy", null);

            return dt;

        }
    }
}
