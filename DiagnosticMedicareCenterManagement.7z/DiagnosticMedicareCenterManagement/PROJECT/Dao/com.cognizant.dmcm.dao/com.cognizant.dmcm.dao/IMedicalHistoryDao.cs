﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.dmcm.model;

namespace com.cognizant.dmcm.dao
{
    interface IMedicalHistoryDao
    {
        int AddMedicalHistory(MedicalTestHistory medicalTestHistory);
        List<MedicalTestHistory> DisplayMedicalTestHistory();
        MedicalTestHistory DisplaySpecificMedicalTestHistory(string PatientId);
        int EditMedicalHistory(MedicalTestHistory medicalTestHistory);


       
    }
}
