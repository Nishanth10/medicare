﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using com.cognizant.dmcm.model;

namespace com.cognizant.dmcm.dao
{
   public class DoctorDaoSqlImpl : IDoctorDao
    {
        static string _callConnection = ConnectionHandler.ConnectionVariable;

        public int DoctorRegistration(Doctor doctor)
        {
            int result = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._registerDoctor
                };

                sqlCommand.Parameters.Add(ConstantsImpl._firstName, SqlDbType.VarChar).Value = doctor.FirstName;
                sqlCommand.Parameters.Add(ConstantsImpl._lastName, SqlDbType.VarChar).Value = doctor.LastName;
                sqlCommand.Parameters.Add(ConstantsImpl._age, SqlDbType.Int).Value = doctor.Age;
                sqlCommand.Parameters.Add(ConstantsImpl._gender, SqlDbType.VarChar).Value = doctor.Gender;
                sqlCommand.Parameters.Add(ConstantsImpl._dob, SqlDbType.VarChar).Value = doctor.DateOfBirth;
                sqlCommand.Parameters.Add(ConstantsImpl._phone, SqlDbType.BigInt).Value = doctor.Phone;
                if (doctor.AlternatePhone == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._alternatePhone, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._alternatePhone, SqlDbType.BigInt).Value = doctor.AlternatePhone;
                }
                sqlCommand.Parameters.Add(ConstantsImpl._email, SqlDbType.VarChar).Value = doctor.Email;
                sqlCommand.Parameters.Add(ConstantsImpl._password, SqlDbType.VarChar).Value = doctor.Password;
                sqlCommand.Parameters.Add(ConstantsImpl._address_line1, SqlDbType.VarChar).Value = doctor.AddressLine1;
                sqlCommand.Parameters.Add(ConstantsImpl._address_line2, SqlDbType.VarChar).Value = doctor.AddressLine2;
                sqlCommand.Parameters.Add(ConstantsImpl._city, SqlDbType.VarChar).Value = doctor.City;
                sqlCommand.Parameters.Add(ConstantsImpl._state, SqlDbType.VarChar).Value = doctor.State;
                sqlCommand.Parameters.Add(ConstantsImpl._zipcode, SqlDbType.BigInt).Value = doctor.Zipcode;
                sqlCommand.Parameters.Add(ConstantsImpl._degree, SqlDbType.VarChar).Value = doctor.Degree;
                sqlCommand.Parameters.Add(ConstantsImpl._speciality, SqlDbType.VarChar).Value = doctor.Speciality;
                sqlCommand.Parameters.Add(ConstantsImpl._workHours, SqlDbType.BigInt).Value = doctor.WorkHours;
                sqlCommand.Parameters.Add(ConstantsImpl._clinicName, SqlDbType.VarChar).Value = doctor.ClinicName;
                sqlCommand.Parameters.Add(ConstantsImpl._medicareServiceId, SqlDbType.BigInt).Value = doctor.MedicareServiceId;


                result = sqlCommand.ExecuteNonQuery();
            }
            return result;
        
    }
        public int DoctorLogin(string DoctorId, string password)
        {
            int logResult = 0;
            using (SqlConnection connection = new SqlConnection(_callConnection))
            {
                connection.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = connection,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._loginDoctor
                };

                SqlDataReader dataReader = sqlCommand.ExecuteReader();
                while (dataReader.Read())
                {
                    if (Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorId))).Equals(DoctorId)
                        && Convert.ToString(dataReader.GetValue(dataReader.GetOrdinal(ConstantsImpl._doctorPassword))).Equals(password))
                    {
                        logResult = 1;
                        break;
                    }
                    else
                    {
                        logResult = 2;
                    }
                }
            }
            return logResult;
        }
    }
}
