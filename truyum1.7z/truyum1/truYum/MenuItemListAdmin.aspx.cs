﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//refer to the DAO
using DAO;
//Create a dataset to hold record collected from DAO method
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            DisplayItemsAdmin();
        }
    }

    protected void gridItem_EditRow(object sender, GridViewEditEventArgs e)
    {
        //Create a row in grid for searching the edition
        GridViewRow row = gridItem.Rows[e.NewEditIndex];
        //extract item ID present in column 0 from grid       
        string itemId = row.Cells[0].Text;
        /*string name = row.Cells[1].Text;
        string price = row.Cells[2].Text;
        string dateoflaunch = row.Cells[4].Text;*/
        Response.Redirect("EditMenuItem.aspx?ItemId="+itemId);
    }

    protected void gridItem_CancelEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gridItem.EditIndex = -1;
    }

    protected void DisplayItemsAdmin()
    {
        MenuItemDaoSQL MenuItemDaoSQL = new MenuItemDaoSQL();
        List<com.cognizant.truyum.model.MenuItem> menuList = MenuItemDaoSQL.GetMenuItemListAdmin();
        gridItem.DataSource = menuList;
        gridItem.DataBind();
        
    }

    protected void gridBoundChange(object sender, GridViewRowEventArgs e)
    {
        //if the active=true change for display as yes otherwise no
        if(e.Row.Cells[3].Text=="True")
        {
            e.Row.Cells[3].Text = "Yes";
        }
        else
        {
            e.Row.Cells[3].Text = "No";
        }

        //if the free delivery=true change for display as yes otherwise no
        if (e.Row.Cells[6].Text == "True")
        {
            e.Row.Cells[6].Text = "Yes";
        }
        else
        {
            e.Row.Cells[6].Text = "No";
        }
    }
}