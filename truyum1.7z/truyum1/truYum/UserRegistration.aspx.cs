﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAO;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void txtSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            AdminUserBL ad = new AdminUserBL();
            int result = ad.UserRegistration(txtFullName.Text, txtPassword.Text,
                long.Parse(txtPhone.Text));
            if(result>0)
            {
                Session["PasswordInfo"] = txtPassword.Text;
                Response.Redirect("RegistrationSuccessInfo.aspx");
            }
            else
            {
                throw new Exception();
            }
        }
        catch(Exception ex)
        {
            Response.Write("<h2 style='color:red;'>Same Password Exist</h2>");
        }
    }
}