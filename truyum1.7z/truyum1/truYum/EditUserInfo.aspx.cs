﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAO;
using com.cognizant.truyum.model;
using com.cognizant.truyum.util;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            lblUserId.Text = Request.QueryString["ItemId"].ToString();
            if(lblUserId.Text!=null || lblUserId.Text!="")
            {
                AdminUserBL ad = new AdminUserBL();
                com.cognizant.truyum.model.User user =
                    ad.DisplaySpecficUserById(int.Parse(lblUserId.Text));

                lblPassword.Text = user.Password;
                lblStatus.Text = user.ActivationStatus;

                if(user.ActivationStatus.
                    Equals("yes",StringComparison.InvariantCulture))
                {
                    statusCheckBox.Checked = true;
                }
                else
                {
                    statusCheckBox.Checked = false;
                }
            }
        }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            AdminUserBL ad = new AdminUserBL();
            int result = ad.EditUserInfo(lblStatus.Text, int.Parse(lblUserId.Text));
            if (result > 0) //update successful
            {
                Response.Write
    ("<script>alert('Update Completed');window.location.href='AdminProcess.aspx'</script>");
            }
            else
            {
                throw new Exception();
            }
        }
        catch(Exception ex)
        {
            Response.Write(ex.Message);
        }    
    }

    protected void statusCheckBox_CheckedChanged(object sender, EventArgs e)
    {
        if (statusCheckBox.Checked == true)
        {
            lblStatus.Text = "yes";
        }
        else
        {
            lblStatus.Text = "no";
        }
    }
}