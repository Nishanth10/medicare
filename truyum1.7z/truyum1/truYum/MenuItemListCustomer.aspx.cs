﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAO;
public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {            
            DisplayItems();
            lblUserId.Text = Session["userId"].ToString();
        }
    }
    //Pascal GrdItemAddButtonClicK
    protected void grdItem_AddButtonClick(object sender, GridViewCommandEventArgs e)
    {
        //find the row number for whose button you are clicking
        int gridviewrowindex = int.Parse(e.CommandArgument.ToString());
        //through row number extract item id
        string menuItemId = gridItem.Rows[gridviewrowindex].Cells[0].Text;
        Session["userId"] = lblUserId.Text.ToString();
        Response.Redirect("AddToCart.aspx?menuItemId=" + menuItemId);        
    }

    public void DisplayItems()
    {
        MenuItemDaoSQL MenuItemDaoSQL = new MenuItemDaoSQL();
        List<com.cognizant.truyum.model.MenuItem> menuList = MenuItemDaoSQL.GetMenuItemListCustomer();
        gridItem.DataSource = menuList;
        gridItem.DataBind();
    }

    protected void gridChangeValue(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.Cells[2].Text == "True")
        {
            e.Row.Cells[2].Text = "Yes";
        }
        else
        {
            e.Row.Cells[2].Text = "No";
        }
    }

    protected void cartBtn_Click(object sender, EventArgs e)
    {
        Session["userId"] = lblUserId.Text.ToString();
        Response.Redirect("Cart.aspx");
    }
}