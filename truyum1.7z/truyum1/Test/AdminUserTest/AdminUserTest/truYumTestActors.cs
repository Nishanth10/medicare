﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
//namespaces for model,dao,util
using com.cognizant.truyum.model;
using com.cognizant.truyum.util;
using DAO;
using System.Linq.Expressions;

namespace AdminUserTest
{
    [TestClass]
    public class truYumTestActors
    {
        /* [TestMethod]
        public void TestUserRegistration()
        {
            AdminUserBL ad = new AdminUserBL();
            int result=ad.UserRegistration("Sam Gomes","sam@123",9600197755);
            //test if result>0 then insert success else failure
            Assert.AreEqual(1, result);
        }*/

        [TestMethod]
        public void TestDisplayUserByPassword()
        {
            AdminUserBL ad = new AdminUserBL();
            com.cognizant.truyum.model.User u = ad.DisplaySpecificUser("joe@123");
            Assert.IsNotNull(u);
        }
    }
}
