IF EXISTS (SELECT * FROM sys.databases WHERE name = N'truyum1')
BEGIN
       DROP DATABASE truyum1
       CREATE DATABASE truyum1
END
ELSE
BEGIN
       CREATE DATABASE truyum1
END
GO

USE truyum1
GO

/****** Object:  Table [dbo].[cart]    Script Date: 7/30/2019 11:46:55 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[cart](
       [ct_id] [int] IDENTITY(1,1) NOT NULL,
       [ct_us_id] [bigint] NULL,
       [ct_me_id] [bigint] NULL,
CONSTRAINT [PK_cart] PRIMARY KEY CLUSTERED 
(
       [ct_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[product]    Script Date: 7/30/2019 11:46:55 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[menu_item](
       [me_id] [bigint] IDENTITY(1,1) NOT NULL,
       [me_name] [varchar](100) NULL,
       [me_price] [decimal](8, 2) NULL,
       [me_active] [varchar](3) NULL,
       [me_date_of_launch] [date] NULL,
       [me_category] [varchar](45) NULL,
       [me_free_delivery] [varchar](3) NULL,
CONSTRAINT [PK_menu_item] PRIMARY KEY CLUSTERED 
(
       [me_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[user]    Script Date: 7/30/2019 11:46:55 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

create table [dbo].[admin]
(
[ad_id] [bigint] IDENTITY(1001,1) NOT NULL,
[ad_password] [varchar](100) unique,
constraint ad_id_pk primary key(ad_id)
);

insert into admin values
('admin1'),
('admin2'),
('admin3');

CREATE TABLE [dbo].[user](
       [us_id] [bigint] IDENTITY(1,1) NOT NULL,
       [us_name] [varchar](100) NULL,
       [us_password] [varchar](100) unique,
       [us_phone] [bigint],
       [us_active] [varchar](60),
CONSTRAINT [PK_user] PRIMARY KEY CLUSTERED 
(
       [us_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
ALTER TABLE [dbo].[cart]  WITH CHECK ADD  CONSTRAINT [ct_me_fk] FOREIGN KEY([ct_me_id])
REFERENCES [dbo].[menu_item] ([me_id])
GO
ALTER TABLE [dbo].[cart] CHECK CONSTRAINT [ct_me_fk]
GO
ALTER TABLE [dbo].[cart]  WITH CHECK ADD  CONSTRAINT [ct_us_fk] FOREIGN KEY([ct_us_id])
REFERENCES [dbo].[user] ([us_id])
GO
ALTER TABLE [dbo].[cart] CHECK CONSTRAINT [ct_us_fk]
GO

