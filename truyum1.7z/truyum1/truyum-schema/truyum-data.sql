use truyum1;

INSERT INTO [menu_item](me_name, me_price, me_active, me_date_of_launch, me_category, me_free_delivery)

VALUES

('SandWich',99.00,'Yes','12/23/2022','Main Course','Yes'),

('Burger',129.00,'Yes','01/23/2024','Main Course','Yes'),

('Pizza',149.00,'Yes','02/03/2018','Main Course','Yes'),

('French Fries',57.00,'Yes','11/08/2017','Starters','Yes'),

('Chocolate Brownie',32.00,'Yes','02/14/2020','Deserts','Yes');





/*

1b.    Frame SQL query to get all menu items.

*/

SELECT me_name AS [Name], me_price AS [Price],

me_active AS [Active], me_date_of_launch AS [Date Of Launch],

me_category AS [Category], me_free_delivery AS [Free Delivery]

FROM [menu_item];





/*

2a.    Frame SQL query to get all menu items which after launch date and is active.

*/

SELECT me_name AS [Name],me_free_delivery AS [Free Delivery], me_price AS [Price], me_category AS [Category]

FROM [menu_item]

WHERE me_date_of_launch > GETDATE() AND me_active = 'Yes';





/*

3a.    Frame SQL query to get a menu items based on Menu Item Id.

*/

SELECT me_name AS [Name], me_free_delivery AS [Free Delivery],

me_price AS [Price], me_category AS [Category]

FROM [menu_item]

WHERE me_id = 4;



delete from [user] where us_id=2;

select * from [user];


/*

3b.    Frame update SQL menu_items table to update all the columns values based on Menu Item Id.

*/

UPDATE [menu_item]

SET me_name = 'Cheese French Fries', me_price = 87,

me_active = 'Yes', me_date_of_launch = '01/10/2019',

me_category = 'Starter', me_free_delivery = 'No'

WHERE me_id = 4;





/*

4a.    Frame insert scripts for adding data into user and cart tables.In user table create two users.

Once user will not have any entries in cart, while the other will have at least 3 items in the cart.

*/




select * from [user];
-- Add Items to Cart for any 1 User.

INSERT INTO [cart](ct_us_id, ct_me_id)

VALUES

(1, 1),

(1, 2),

(1, 5);


select * from cart;

/*

5a.    Frame SQL query to get all menu items in a particular user�s cart.

*/

SELECT m.me_name AS [Name], m.me_free_delivery AS [Free Delivery], m.me_price AS [Price]

FROM [menu_item] m JOIN [cart] c

ON m.me_id = c.ct_me_id AND c.ct_us_id = 1;





/*

5b.    Frame SQL query to get the total price of all menu items in a particular user�s cart.

*/

SELECT SUM(m.me_price) AS [Total Price]

FROM [menu_item] m JOIN [cart] c

ON m.me_id = c.ct_me_id AND c.ct_us_id = 1;





/*

6a.    Frame SQL query to remove a menu items from Cart based on User Id and Menu Item Id.

*/

DELETE FROM [cart]

WHERE ct_us_id = 1 AND ct_me_id = 1;

select * from [admin];
select * from [user];

select * from menu_item;
