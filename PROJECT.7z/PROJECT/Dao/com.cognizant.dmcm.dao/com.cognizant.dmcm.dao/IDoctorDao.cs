﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.cognizant.dmcm.model;

namespace com.cognizant.dmcm.dao
{
    interface IDoctorDao
    {
        int DoctorRegistration(Doctor doctor);

        int DoctorLogin(String DoctorId, string password);
    }
}
