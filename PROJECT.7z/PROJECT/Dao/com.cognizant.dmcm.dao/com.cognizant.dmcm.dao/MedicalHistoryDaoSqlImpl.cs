﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using com.cognizant.dmcm.model;

namespace com.cognizant.dmcm.dao
{
    public class MedicalHistoryDaoSqlImpl : IMedicalHistoryDao
    {
        static string _callConnection = ConnectionHandler.ConnectionVariable;
        public int AddMedicalHistory(MedicalTestHistory medicalTestHistory)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(_callConnection))
            {
                con.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._addHistory
                };

                sqlCommand.Parameters.Add(ConstantsImpl._ptId, SqlDbType.VarChar).Value = medicalTestHistory.PatientId;
                sqlCommand.Parameters.Add(ConstantsImpl._doId, SqlDbType.VarChar).Value = medicalTestHistory.DoctorId;
                sqlCommand.Parameters.Add(ConstantsImpl._medicareServiceId, SqlDbType.BigInt).Value = medicalTestHistory.MedicareServiceId;
                sqlCommand.Parameters.Add(ConstantsImpl._serviceDate, SqlDbType.VarChar).Value = medicalTestHistory.ServiceDate;
                sqlCommand.Parameters.Add(ConstantsImpl._testResultDate, SqlDbType.VarChar).Value = medicalTestHistory.TestResultDate;
                sqlCommand.Parameters.Add(ConstantsImpl._diag1ActualValue, SqlDbType.BigInt).Value = medicalTestHistory.Diag1ActualValue;
                sqlCommand.Parameters.Add(ConstantsImpl._diag1NormalRange, SqlDbType.BigInt).Value = medicalTestHistory.Diag1NormalRange;

                if (medicalTestHistory.Diag2ActualValue == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag2ActualValue, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag2ActualValue, SqlDbType.BigInt).Value = medicalTestHistory.Diag2ActualValue;
                }
                if (medicalTestHistory.Diag2NormalRange == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag2NormalRange, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag2NormalRange, SqlDbType.BigInt).Value = medicalTestHistory.Diag2NormalRange;
                }


                if (medicalTestHistory.Diag3ActualValue == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag3ActualValue, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag3ActualValue, SqlDbType.BigInt).Value = medicalTestHistory.Diag3ActualValue;
                }
                if (medicalTestHistory.Diag3NormalRange == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag3NormalRange, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag3NormalRange, SqlDbType.BigInt).Value = medicalTestHistory.Diag3NormalRange;
                }


                if (medicalTestHistory.Diag4ActualValue == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag4ActualValue, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag4ActualValue, SqlDbType.BigInt).Value = medicalTestHistory.Diag4ActualValue;
                }
                if (medicalTestHistory.Diag4NormalRange == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag4NormalRange, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag4NormalRange, SqlDbType.BigInt).Value = medicalTestHistory.Diag4NormalRange;
                }


                if (medicalTestHistory.Diag5ActualValue == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag5ActualValue, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag5ActualValue, SqlDbType.BigInt).Value = medicalTestHistory.Diag5ActualValue;
                }
                if (medicalTestHistory.Diag5NormalRange == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag5NormalRange, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag5NormalRange, SqlDbType.BigInt).Value = medicalTestHistory.Diag5NormalRange;
                }


                if (medicalTestHistory.Diag6ActualValue == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag6ActualValue, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag6ActualValue, SqlDbType.BigInt).Value = medicalTestHistory.Diag6ActualValue;
                }
                if (medicalTestHistory.Diag6NormalRange == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag6NormalRange, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag6NormalRange, SqlDbType.BigInt).Value = medicalTestHistory.Diag6NormalRange;
                }
                sqlCommand.Parameters.Add(ConstantsImpl._doctorComments, SqlDbType.VarChar).Value = medicalTestHistory.DoctorComments;
                sqlCommand.Parameters.Add(ConstantsImpl._otherInfo, SqlDbType.VarChar).Value = medicalTestHistory.OtherInfo;


                result = sqlCommand.ExecuteNonQuery();
            }
            return result;
        }

        public List<MedicalTestHistory> DisplayMedicalTestHistory()
        {
            List<MedicalTestHistory> medicalTestHistoryList = new List<MedicalTestHistory>();


            using (SqlConnection con = new SqlConnection(_callConnection))
            {
                con.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._viewMedicalHistory
                };

                SqlDataReader dr = sqlCommand.ExecuteReader();
                while (dr.Read())
                {
                    MedicalTestHistory medicalTestHistory = new MedicalTestHistory();

                    medicalTestHistory.ReportId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._rId)));
                    medicalTestHistory.PatientId = Convert.ToString(dr.GetValue(dr.GetOrdinal(ConstantsImpl._pId)));
                    medicalTestHistory.DoctorId = Convert.ToString(dr.GetValue(dr.GetOrdinal(ConstantsImpl._dId)));
                    medicalTestHistory.MedicareServiceId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._msId)));
                    medicalTestHistory.ServiceDate = Convert.ToString(dr.GetValue(dr.GetOrdinal(ConstantsImpl._sDate)));
                    medicalTestHistory.TestResultDate = Convert.ToString(dr.GetValue(dr.GetOrdinal(ConstantsImpl._tResultDate)));
                    medicalTestHistory.Diag1ActualValue = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d1ActualValue)));
                    medicalTestHistory.Diag1NormalRange = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d1NormalRange)));

                    medicalTestHistory.Diag2ActualValue = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d2ActualValue)));

                    medicalTestHistory.Diag2NormalRange = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d2NormalRange)));




                    medicalTestHistory.Diag3ActualValue = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d3ActualValue)));


                    medicalTestHistory.Diag3NormalRange = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d3NormalRange)));



                    medicalTestHistory.Diag4ActualValue = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d4ActualValue)));

                    medicalTestHistory.Diag4NormalRange = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d4NormalRange)));

                    medicalTestHistory.Diag5ActualValue = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d5ActualValue)));

                    medicalTestHistory.Diag5NormalRange = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d5NormalRange)));

                    medicalTestHistory.Diag6ActualValue = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d6ActualValue)));

                    medicalTestHistory.Diag6NormalRange = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d6NormalRange)));

                    medicalTestHistory.DoctorComments = Convert.ToString(dr.GetValue(dr.GetOrdinal(ConstantsImpl._dComments)));
                    medicalTestHistory.OtherInfo = Convert.ToString(dr.GetValue(dr.GetOrdinal(ConstantsImpl._oInfo)));
                    medicalTestHistoryList.Add(medicalTestHistory);
                }
                return medicalTestHistoryList;
            }
        }

        public MedicalTestHistory DisplaySpecificMedicalTestHistory(string PatientId)
        {
           
            using (SqlConnection con = new SqlConnection(_callConnection))
            {
                con.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._displayFilteredMedicalHistoryById
                };
                sqlCommand.Parameters.Add("@patientId", SqlDbType.VarChar).Value = PatientId;
                SqlDataReader dr = sqlCommand.ExecuteReader();
                MedicalTestHistory medicalTestHistory = new MedicalTestHistory();
                while (dr.Read())
                {

                    medicalTestHistory.ReportId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._rId)));
                    medicalTestHistory.PatientId = Convert.ToString(dr.GetValue(dr.GetOrdinal(ConstantsImpl._pId)));
                    medicalTestHistory.DoctorId = Convert.ToString(dr.GetValue(dr.GetOrdinal(ConstantsImpl._dId)));
                    medicalTestHistory.MedicareServiceId = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._msId)));
                    medicalTestHistory.ServiceDate = Convert.ToString(dr.GetValue(dr.GetOrdinal(ConstantsImpl._sDate)));
                    medicalTestHistory.TestResultDate = Convert.ToString(dr.GetValue(dr.GetOrdinal(ConstantsImpl._tResultDate)));
                    medicalTestHistory.Diag1ActualValue = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d1ActualValue)));
                    medicalTestHistory.Diag1NormalRange = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d1NormalRange)));

                    medicalTestHistory.Diag2ActualValue = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d2ActualValue)));

                    medicalTestHistory.Diag2NormalRange = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d2NormalRange)));




                    medicalTestHistory.Diag3ActualValue = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d3ActualValue)));


                    medicalTestHistory.Diag3NormalRange = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d3NormalRange)));



                    medicalTestHistory.Diag4ActualValue = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d4ActualValue)));

                    medicalTestHistory.Diag4NormalRange = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d4NormalRange)));

                    medicalTestHistory.Diag5ActualValue = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d5ActualValue)));

                    medicalTestHistory.Diag5NormalRange = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d5NormalRange)));

                    medicalTestHistory.Diag6ActualValue = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d6ActualValue)));

                    medicalTestHistory.Diag6NormalRange = Convert.ToInt32(dr.GetValue(dr.GetOrdinal(ConstantsImpl._d6NormalRange)));

                    medicalTestHistory.DoctorComments = Convert.ToString(dr.GetValue(dr.GetOrdinal(ConstantsImpl._dComments)));
                    medicalTestHistory.OtherInfo = Convert.ToString(dr.GetValue(dr.GetOrdinal(ConstantsImpl._oInfo)));
                }
                return medicalTestHistory;
            }
        }

        public int EditMedicalHistory(MedicalTestHistory medicalTestHistory)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(_callConnection))
            {
                con.Open();
                SqlCommand sqlCommand = new SqlCommand
                {
                    Connection = con,
                    CommandType = CommandType.Text,
                    CommandText = QueriesImpl._updateMedicalHistory
                };

                sqlCommand.Parameters.Add(ConstantsImpl._reportId, SqlDbType.BigInt).Value = medicalTestHistory.ReportId;
                sqlCommand.Parameters.Add(ConstantsImpl._ptId, SqlDbType.VarChar).Value = medicalTestHistory.PatientId;
                sqlCommand.Parameters.Add(ConstantsImpl._doId, SqlDbType.VarChar).Value = medicalTestHistory.DoctorId;
                sqlCommand.Parameters.Add(ConstantsImpl._medicareServiceId, SqlDbType.BigInt).Value = medicalTestHistory.MedicareServiceId;
                sqlCommand.Parameters.Add(ConstantsImpl._serviceDate, SqlDbType.VarChar).Value = medicalTestHistory.ServiceDate;
                sqlCommand.Parameters.Add(ConstantsImpl._testResultDate, SqlDbType.VarChar).Value = medicalTestHistory.TestResultDate;
                sqlCommand.Parameters.Add(ConstantsImpl._diag1ActualValue, SqlDbType.BigInt).Value = medicalTestHistory.Diag1ActualValue;
                sqlCommand.Parameters.Add(ConstantsImpl._diag1NormalRange, SqlDbType.BigInt).Value = medicalTestHistory.Diag1NormalRange;
                if (medicalTestHistory.Diag2ActualValue == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag2ActualValue, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag2ActualValue, SqlDbType.BigInt).Value = medicalTestHistory.Diag2ActualValue;
                }
                if (medicalTestHistory.Diag2NormalRange == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag2NormalRange, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag2NormalRange, SqlDbType.BigInt).Value = medicalTestHistory.Diag2NormalRange;
                }


                if (medicalTestHistory.Diag3ActualValue == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag3ActualValue, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag3ActualValue, SqlDbType.BigInt).Value = medicalTestHistory.Diag3ActualValue;
                }
                if (medicalTestHistory.Diag3NormalRange == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag3NormalRange, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag3NormalRange, SqlDbType.BigInt).Value = medicalTestHistory.Diag3NormalRange;
                }


                if (medicalTestHistory.Diag4ActualValue == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag4ActualValue, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag4ActualValue, SqlDbType.BigInt).Value = medicalTestHistory.Diag4ActualValue;
                }
                if (medicalTestHistory.Diag4NormalRange == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag4NormalRange, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag4NormalRange, SqlDbType.BigInt).Value = medicalTestHistory.Diag4NormalRange;
                }


                if (medicalTestHistory.Diag5ActualValue == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag5ActualValue, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag5ActualValue, SqlDbType.BigInt).Value = medicalTestHistory.Diag5ActualValue;
                }
                if (medicalTestHistory.Diag5NormalRange == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag5NormalRange, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag5NormalRange, SqlDbType.BigInt).Value = medicalTestHistory.Diag5NormalRange;
                }


                if (medicalTestHistory.Diag6ActualValue == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag6ActualValue, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag6ActualValue, SqlDbType.BigInt).Value = medicalTestHistory.Diag6ActualValue;
                }
                if (medicalTestHistory.Diag6NormalRange == 0)
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag6NormalRange, SqlDbType.BigInt).Value = 0;
                }
                else
                {
                    sqlCommand.Parameters.Add(ConstantsImpl._diag6NormalRange, SqlDbType.BigInt).Value = medicalTestHistory.Diag6NormalRange;
                }
                sqlCommand.Parameters.Add(ConstantsImpl._doctorComments, SqlDbType.VarChar).Value = medicalTestHistory.DoctorComments;
                sqlCommand.Parameters.Add(ConstantsImpl._otherInfo, SqlDbType.VarChar).Value = medicalTestHistory.OtherInfo;

                result = sqlCommand.ExecuteNonQuery();
            }
            return result;
        }
    }
}
       