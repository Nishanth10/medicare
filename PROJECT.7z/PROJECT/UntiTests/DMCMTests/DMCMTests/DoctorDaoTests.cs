﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;

namespace DMCMTests
{
    [TestClass]
    public class DoctorDaoTests
    {
        /* [TestMethod]
         public void TestDoctorRegistration()
         {
             DoctorDaoSqlImpl doctorDao = new DoctorDaoSqlImpl();
             Doctor doctor = new Doctor();
             doctor.FirstName = "Jughi";
             doctor.LastName = "Sathvi";
             doctor.Age = 70;
             doctor.Gender = "FeMale";
             doctor.DateOfBirth = "22/09/1832";
             doctor.Phone = 8973364443;
             doctor.AlternatePhone = 8110072333;
             doctor.Email = "jughi@gmail.com";
             doctor.Password = "jughi@123";
             doctor.AddressLine1 = "Perundurai";
             doctor.AddressLine2 = "R.S.Road";
             doctor.City = "Erode";
             doctor.State = "TamilNadu";
             doctor.Zipcode = 638052;
             doctor.Degree = "MBBS";
             doctor.Speciality = "Child";
             doctor.WorkHours = 4;
             doctor.ClinicName = "MultiSpeciality";
             doctor.MedicareServiceId = 1;
             int result = doctorDao.DoctorRegistration(doctor);
             Assert.AreEqual(1, result);

         }*/



        /*[TestMethod]
        public void TestDoctorLogin()
        {
          DoctorDaoSqlImpl doctorDao = new DoctorDaoSqlImpl();
          int result = doctorDao.DoctorLogin("DOC002","vinci@3");
          Assert.AreEqual(1,result);
        }*/


        [TestMethod]
        public void TestDoctorLogin()
        {
          DoctorDaoSqlImpl doctorDao = new DoctorDaoSqlImpl();
          int result = doctorDao.DoctorLogin("DOC013", "jughi@123");
          Assert.AreEqual(1, result);
        }
    }
}

