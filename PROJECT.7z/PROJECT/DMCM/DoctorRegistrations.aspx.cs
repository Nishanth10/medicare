﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using com.cognizant.dmcm.dao;
using com.cognizant.dmcm.model;
using com.cognizant.dmcm.util;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ddlGender.Items.Add("Select Gender");
            ddlGender.Items.Add("Male");
            ddlGender.Items.Add("Female");

            long msId = 1;
            txtMsId.Text = msId.ToString(); 
        }
    }


    protected void BtnDoctorRegister_Click(object sender, EventArgs e)
    {
        DoctorDaoSqlImpl doctorDao = new DoctorDaoSqlImpl();
        Doctor doctor = new Doctor();
        doctor.FirstName = txtFirstName.Text;
        doctor.LastName = txtLastName.Text;
        doctor.Age = int.Parse(txtAge.Text);
        doctor.Gender = ddlGender.SelectedItem.Text;
        doctor.DateOfBirth = txtDob.Text;
        doctor.Phone = long.Parse(txtPhone.Text);
        if (txtAltPhone.Text == "")
        {
            doctor.AlternatePhone = 0;
        }
        else
        {
            doctor.AlternatePhone = long.Parse(txtAltPhone.Text);
        }
      
        doctor.Email = txtEmail.Text;
        doctor.Password = txtPwd.Text;
        doctor.AddressLine1 = txtAdrs1.Text;
        doctor.AddressLine2 = txtAdrs2.Text;
        doctor.City = txtCity.Text;
        doctor.State = txtState.Text;
        doctor.Zipcode = long.Parse(txtZipCode.Text);
        doctor.Degree = txtDegree.Text;
        doctor.Speciality = txtSpeciality.Text;
        doctor.WorkHours = long.Parse(txtWorkHours.Text);
        doctor.ClinicName = txtClinicName.Text;
        doctor.MedicareServiceId = long.Parse(txtMsId.Text);


        if (doctorDao.DoctorRegistration(doctor) == 1)
        {
            Response.Write("<script>alert('Registration Successful');window.location.href='Home.aspx'</script>");
        }
        else
        {
            Response.Write("<script>alert('Registration Failed');window.location.href='DoctorRegistration.aspx'</script>");
        }
    }
}