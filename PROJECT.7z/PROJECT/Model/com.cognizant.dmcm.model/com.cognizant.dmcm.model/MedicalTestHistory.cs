﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.cognizant.dmcm.model
{
    public class MedicalTestHistory
    {

        private int _reportId;
        private string _patientId;
        private string _doctorId;
        private long _medicareServiceId;
        private string _serviceDate;
        private string _testResultDate;
        private long _diag1ActualValue;
        private long _diag1NormalRange;
        private long _diag2ActualValue;
        private long _diag2NormalRange;
        private long _diag3ActualValue;
        private long _diag3NormalRange;
        private long _diag4ActualValue;
        private long _diag4NormalRange;
        private long _diag5ActualValue;
        private long _diag5NormalRange;
        private long _diag6ActualValue;
        private long _diag6NormalRange;
        private string _doctorComments;
        private string _otherInfo;

        public int ReportId
        {
            get
            {
                return _reportId;
            }

            set
            {
                _reportId = value;
            }
        }
        public string PatientId
        {
            get
            {
                return _patientId;
            }

            set
            {
                _patientId = value;
            }
        }

        public string DoctorId
        {
            get
            {
                return _doctorId;
            }

            set
            {
                _doctorId = value;
            }
        }

        public long MedicareServiceId
        {
            get
            {
                return _medicareServiceId;
            }

            set
            {
                _medicareServiceId = value;
            }
        }

        public string ServiceDate
        {
            get
            {
                return _serviceDate;
            }

            set
            {
                _serviceDate = value;
            }
        }

        public string TestResultDate
        {
            get
            {
                return _testResultDate;
            }

            set
            {
                _testResultDate = value;
            }
        }

        public long Diag1ActualValue
        {
            get
            {
                return _diag1ActualValue;
            }

            set
            {
                _diag1ActualValue = value;
            }
        }

        public long Diag1NormalRange
        {
            get
            {
                return _diag1NormalRange;
            }

            set
            {
                _diag1NormalRange = value;
            }
        }

        public long Diag2ActualValue
        {
            get
            {
                return _diag2ActualValue;
            }

            set
            {
                _diag2ActualValue = value;
            }
        }

        public long Diag2NormalRange
        {
            get
            {
                return _diag2NormalRange;
            }

            set
            {
                _diag2NormalRange = value;
            }
        }

        public long Diag3ActualValue
        {
            get
            {
                return _diag3ActualValue;
            }

            set
            {
                _diag3ActualValue = value;
            }
        }

        public long Diag3NormalRange
        {
            get
            {
                return _diag3NormalRange;
            }

            set
            {
                _diag3NormalRange = value;
            }
        }

        public long Diag4ActualValue
        {
            get
            {
                return _diag4ActualValue;
            }

            set
            {
                _diag4ActualValue = value;
            }
        }

        public long Diag4NormalRange
        {
            get
            {
                return _diag4NormalRange;
            }

            set
            {
                _diag4NormalRange = value;
            }
        }

        public long Diag5ActualValue
        {
            get
            {
                return _diag5ActualValue;
            }

            set
            {
                _diag5ActualValue = value;
            }
        }

        public long Diag5NormalRange
        {
            get
            {
                return _diag5NormalRange;
            }

            set
            {
                _diag5NormalRange = value;
            }
        }

        public long Diag6ActualValue
        {
            get
            {
                return _diag6ActualValue;
            }

            set
            {
                _diag6ActualValue = value;
            }
        }

        public long Diag6NormalRange
        {
            get
            {
                return _diag6NormalRange;
            }

            set
            {
                _diag6NormalRange = value;
            }
        }

        public string DoctorComments
        {
            get
            {
                return _doctorComments;
            }

            set
            {
                _doctorComments = value;
            }
        }

        public string OtherInfo
        {
            get
            {
                return _otherInfo;
            }

            set
            {
                _otherInfo = value;
            }
        }

        public MedicalTestHistory()
        {

        }

        public MedicalTestHistory(int _reportId,string _patientId, string _doctorId, long _medicareServiceId, string _serviceDate, string _testResultDate, long _diag1ActualValue, long _diag1NormalRange, long _diag2ActualValue, long _diag2NormalRange, long _diag3ActualValue, long _diag3NormalRange, long _diag4ActualValue, long _diag4NormalRange, long _diag5ActualValue, long _diag5NormalRange, long _diag6ActualValue, long _diag6NormalRange, string _doctorComments, string _otherInfo)
        {
            this._reportId = _reportId;
            this._patientId = _patientId;
            this._doctorId = _doctorId;
            this._medicareServiceId = _medicareServiceId;
            this._serviceDate = _serviceDate;
            this._testResultDate = _testResultDate;
            this._diag1ActualValue = _diag1ActualValue;
            this._diag1NormalRange = _diag1NormalRange;
            this._diag2ActualValue = _diag2ActualValue;
            this._diag2NormalRange = _diag2NormalRange;
            this._diag3ActualValue = _diag3ActualValue;
            this._diag3NormalRange = _diag3NormalRange;
            this._diag4ActualValue = _diag4ActualValue;
            this._diag4NormalRange = _diag4NormalRange;
            this._diag5ActualValue = _diag5ActualValue;
            this._diag5NormalRange = _diag5NormalRange;
            this._diag6ActualValue = _diag6ActualValue;
            this._diag6NormalRange = _diag6NormalRange;
            this._doctorComments = _doctorComments;
            this._otherInfo = _otherInfo;
        }
    }
}
